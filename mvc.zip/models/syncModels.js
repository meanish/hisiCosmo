// const sequelize = require('../database/conn');
// const { Brand, Media} = require('./association');

// // Sync models and setup associations
// // Sync models and setup associations
// sequelize.sync()  // Use force: true to reset the database and apply constraints
//     .then(() => {
//         console.log("Database synchronized successfully.");
//     })
//     .catch((error) => {
//         console.error('Failed to synchronize the database:', error);
//     });